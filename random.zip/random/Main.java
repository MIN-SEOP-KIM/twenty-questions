package sungil.random;

import java.util.Random;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("이름이 무엇인가요?");
        Scanner sc = new Scanner(System.in);
        String a = sc.next();

        Random random = new Random();

        boolean chk = true;
        int rns = random.nextInt(10) + 1;
        System.out.println(a + "님 실행할까요?  예 1 번 아니요 2번");

        int d = sc.nextInt();

        if(d==1) System.out.println("게임을 시작합니다");
        if (d == 1) {
            while (chk) {
                int c = sc.nextInt();
                if (c == rns) {
                    System.out.println("맞췄습니다! 종료할께용");
                    chk = false;
                } else {
                    System.out.println("엄.. 아닌거 같은데요?");
                }
            }
        } else if (d==2){
            System.out.println("종료 합니다");
        }
        else{
            System.out.println("잘못 선택하였습니다 종료합니다");
        }
    }
}
